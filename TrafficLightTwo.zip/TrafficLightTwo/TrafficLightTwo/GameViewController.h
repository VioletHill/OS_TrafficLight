//
//  GameViewController.h
//  TrafficLightTwo
//
//  Created by 邱峰 on 12-11-8.
//  Copyright (c) 2012年 VioletHill. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GameLight.h"

@interface GameViewController : UIViewController

@property (strong, nonatomic) IBOutlet GameLight *light;
-(void) gameover;

@end
