//
//  Car.h
//  TrafficLightTwo
//
//  Created by 邱峰 on 12-11-9.
//  Copyright (c) 2012年 VioletHill. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GameViewController.h"
#import <UIKit/UIButton.h>

const static int carWide=30;
const static int carLength=40;
static int specialCarSpeed=10;
static int normalCarSpeed=5;
static GameViewController *gameViewController;

@interface GameCar : NSObject
{
@public
    int speed;
    int state;
    int carDistance;
    NSMutableArray *queueCar;
    UIView * view;
    int direction;
    UIButton *carView;
    bool whoAmI;
    bool stop;
}

-(BOOL) checkBeforeAndAfter:(CGPoint)point;
-(BOOL) checkLeftRihtwithQueue:(NSMutableArray *)queue;
-(void) move;

-(void) addCarAtPoint:(CGPoint) point;
-(void) AtView:(UIView *) outsideView AtDirection:(int)whichDirection inQueue:(NSMutableArray *)queue withWho:(BOOL)isSpecial;
-(BOOL) runRedLight:(int)lightDirection;
+(void) changeSpeed;
+(void) setGameViewController:(GameViewController *)viewController;
+(void) setSpecialCarSpeed:(int) speed;
+(void) setNormalCarSpeed:(int) speed;
@end
