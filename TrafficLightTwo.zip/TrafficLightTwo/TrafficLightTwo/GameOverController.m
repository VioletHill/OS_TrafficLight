//
//  GameOverController.m
//  TrafficLightTwo
//
//  Created by 邱峰 on 12-11-12.
//  Copyright (c) 2012年 VioletHill. All rights reserved.
//

#import "GameOverController.h"
#import "TopScoreViewController.h"
@interface GameOverController ()


@end

@implementation GameOverController
{
    NSString *name;
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
- (IBAction)setName:(UITextField* )sender
{
    name=sender.text;
}
- (IBAction)pressEnter:(UIButton *)sender
{
    [TopScoreViewController setScore:self.score withName:name];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
