//
//  GameLight.m
//  TrafficLightTwo
//
//  Created by 邱峰 on 12-11-8.
//  Copyright (c) 2012年 VioletHill. All rights reserved.
//

#import "GameLight.h"

@implementation GameLight
@synthesize direction=_direction;
@synthesize farDistance=_farDistance;
@synthesize shortDistance=_shortDistance;
@synthesize color=_color;

-(void) setDirection:(int)direction
{
    _direction=direction;
    _color=[UIColor purpleColor];
    [self setNeedsDisplay];
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
    }
    return self;
}

-(void) setColor:(UIColor *)color
{
    _color=color;
    [self setNeedsDisplay];
}

- (void)drawRect:(CGRect)rect
{
    CGPoint midPoint;
    CGPoint point[4];
    midPoint.x=self.bounds.size.width/2;
    midPoint.y=self.bounds.size.height/2;
    point[0].x=midPoint.x-103;
    point[0].y=midPoint.y-103;
    
    point[1].x=midPoint.x+103;
    point[1].y=midPoint.y-103;
    
    point[2].x=midPoint.x+103;
    point[2].y=midPoint.y+103;
    
    point[3].x=midPoint.x-103;
    point[3].y=midPoint.y+103;
    CGContextRef context=UIGraphicsGetCurrentContext();
    
    CGContextSetLineWidth(context, 20);
    //红灯界限
    if (_direction==0)
    {
        [_color set];
        CGContextMoveToPoint(context, point[1].x+_farDistance, point[1].y);
        CGContextAddLineToPoint(context, point[2].x+_farDistance, point[2].y);
        CGContextMoveToPoint(context, point[3].x-_farDistance, point[3].y);
        CGContextAddLineToPoint(context, point[0].x-_farDistance, point[0].y);
        CGContextStrokePath(context);
    }
    if (_direction==1)
    {
        [_color set];
        CGContextMoveToPoint(context, point[0].x, point[0].y-_farDistance);
        CGContextAddLineToPoint(context, point[1].x, point[1].y-_farDistance);
        CGContextMoveToPoint(context, point[2].x, point[2].y+_farDistance);
        CGContextAddLineToPoint(context, point[3].x, point[3].y+_farDistance);
        CGContextStrokePath(context);
    }
    
    [[UIColor yellowColor] set];
    CGContextMoveToPoint(context, point[0].x, point[0].y-_shortDistance);
    CGContextAddLineToPoint(context, point[1].x, point[1].y-_shortDistance);
    CGContextMoveToPoint(context, point[2].x, point[2].y+_shortDistance);
    CGContextAddLineToPoint(context, point[3].x, point[3].y+_shortDistance);
    CGContextStrokePath(context);
    
    CGContextMoveToPoint(context, point[1].x+_shortDistance, point[1].y);
    CGContextAddLineToPoint(context, point[2].x+_shortDistance, point[2].y);
    CGContextMoveToPoint(context, point[3].x-_shortDistance, point[3].y);
    CGContextAddLineToPoint(context, point[0].x-_shortDistance, point[0].y);
    CGContextStrokePath(context);
     
    
    //绿灯
    [[UIColor greenColor] set];
    CGContextMoveToPoint(context, point[_direction].x, point[_direction].y);
    CGContextAddLineToPoint(context, point[_direction+1].x,point[_direction+1].y);
    CGContextStrokePath(context);
    
    CGContextMoveToPoint(context, point[_direction+2].x, point[_direction+2].y);
    CGContextAddLineToPoint(context, point[(_direction+3)%4].x, point[(_direction+3)%4].y);
    CGContextStrokePath(context);
    
    //红灯
    [[UIColor redColor] set];
    CGContextMoveToPoint(context, point[_direction^1].x, point[_direction^1].y);
    CGContextAddLineToPoint(context, point[(_direction^1)+1].x, point[(_direction^1)+1].y);
    CGContextStrokePath(context);
    
    CGContextMoveToPoint(context, point[((_direction^1))+2].x, point[(_direction^1)+2].y);
    CGContextAddLineToPoint(context, point[((_direction^1)+3)%4].x, point[((_direction^1)+3)%4].y);
    CGContextStrokePath(context);

    //道路外面的粗黑线
    [[UIColor blackColor] set];
    CGContextMoveToPoint(context, point[0].x, point[0].y+10);
    CGContextAddLineToPoint(context, point[0].x, 0);
    CGContextMoveToPoint(context, point[0].x+10, point[0].y);
    CGContextAddLineToPoint(context, 0, point[0].y);
    
    CGContextMoveToPoint(context, point[1].x, point[1].y+10);
    CGContextAddLineToPoint(context, point[1].x, 0);
    CGContextMoveToPoint(context, point[1].x, point[1].y);
    CGContextAddLineToPoint(context, self.bounds.size.width, point[1].y);
    
    CGContextMoveToPoint(context, point[2].x-10, point[2].y);
    CGContextAddLineToPoint(context,self.bounds.size.width, point[2].y);
    CGContextMoveToPoint(context, point[2].x, point[2].y);
    CGContextAddLineToPoint(context, point[2].x, self.bounds.size.height);
    
    CGContextMoveToPoint(context, point[3].x+10, point[3].y);
    CGContextAddLineToPoint(context, 0, point[3].y);
    CGContextMoveToPoint(context, point[3].x, point[3].y);
    CGContextAddLineToPoint(context, point[3].x, self.bounds.size.height);
    CGContextStrokePath(context);
    
    //道路中间的分隔线
    [[UIColor blackColor] set];
    CGContextSetLineWidth(context, 6);
    CGContextMoveToPoint(context, midPoint.x, 0);
    CGContextAddLineToPoint(context, midPoint.x, point[0].y-10);
    CGContextMoveToPoint(context, midPoint.x, self.bounds.size.height);
    CGContextAddLineToPoint(context, midPoint.x, point[2].y+10);
    CGContextMoveToPoint(context, 0, midPoint.y);
    CGContextAddLineToPoint(context, point[0].x-10, midPoint.y);
    CGContextMoveToPoint(context, self.bounds.size.width, midPoint.y);
    CGContextAddLineToPoint(context, point[1].x+10, midPoint.y);
    CGContextStrokePath(context);
    //上下虚线
    float lengthsUpDown[]={60,60};
    [[UIColor grayColor] set];
    CGContextSetLineWidth(context, 1);
    CGContextSetLineDash(context, -30, lengthsUpDown, 1);
    CGContextMoveToPoint(context, midPoint.x-50, 0);
    CGContextAddLineToPoint(context, midPoint.x-50, point[0].y-10);
    CGContextMoveToPoint(context, midPoint.x-50,self.bounds.size.height);
    CGContextAddLineToPoint(context, midPoint.x-50, point[2].y+10);
    
    CGContextMoveToPoint(context, midPoint.x+50, 0);
    CGContextAddLineToPoint(context, midPoint.x+50, point[0].y-10);
    CGContextMoveToPoint(context, midPoint.x+50,self.bounds.size.height);
    CGContextAddLineToPoint(context, midPoint.x+50, point[2].y+10);
    
    CGContextStrokePath(context);
    
    //左右虚线
    float lengthsLeftRight[]={64,64};
    CGContextSetLineDash(context, -32, lengthsLeftRight, 1);
    CGContextMoveToPoint(context, 0, midPoint.y-50);
    CGContextAddLineToPoint(context, point[0].x-10, midPoint.y-50);
    CGContextMoveToPoint(context, self.bounds.size.width, midPoint.y-50);
    CGContextAddLineToPoint(context, point[1].x+10, midPoint.y-50);
    
    CGContextMoveToPoint(context, 0, midPoint.y+50);
    CGContextAddLineToPoint(context, point[0].x-10, midPoint.y+50);
    CGContextMoveToPoint(context, self.bounds.size.width, midPoint.y+50);
    CGContextAddLineToPoint(context, point[1].x+10, midPoint.y+50);
    CGContextStrokePath(context);


}


@end
