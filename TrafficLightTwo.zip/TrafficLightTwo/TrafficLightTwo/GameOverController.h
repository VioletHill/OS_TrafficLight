//
//  GameOverController.h
//  TrafficLightTwo
//
//  Created by 邱峰 on 12-11-12.
//  Copyright (c) 2012年 VioletHill. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GameOverController : UIViewController
@property (nonatomic) int score;
@end
