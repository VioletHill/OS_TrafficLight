//
//  TopScoreViewController.m
//  TrafficLightTwo
//
//  Created by 邱峰 on 12-11-12.
//  Copyright (c) 2012年 VioletHill. All rights reserved.
//

#import "TopScoreViewController.h"

@interface TopScoreViewController ()

@end

@implementation TopScoreViewController
{
    
}
static int top=10;
static int topScore[10];


+(BOOL) isTop:(int)score
{
    NSUserDefaults *defaults=[NSUserDefaults standardUserDefaults];
    NSNumber *num=[defaults objectForKey:[@"top" stringByAppendingFormat:@"%d",top-1] ];
    if (score>=num.intValue) return true;
    else return false;
}

+(void) setScore:(int)score withName:(NSString *)str
{
    NSString *strName[top];
    NSUserDefaults *defaults=[NSUserDefaults standardUserDefaults];
    for (int i=0; i<top; i++)
    {
        NSNumber *num=[defaults objectForKey:[@"top" stringByAppendingFormat:@"%d",i] ];
        strName[i]=[defaults objectForKey:[@"topName" stringByAppendingFormat:@"%d",i] ];
        topScore[i]=num.intValue;
    }
    for (int i=0; i<top; i++)
    {
        if (score>=topScore[i])
        {
            for (int j=top-1; j>i; j--)
            {
                topScore[j]=topScore[j-1];
                strName[j]=strName[j-1];
            }
            topScore[i]=score;
            strName[i]=str;
            break;
        }
    }
    for (int i=0; i<top; i++)
    {
        [defaults setObject:[NSNumber numberWithInt:topScore[i] ] forKey:[@"top" stringByAppendingFormat:@"%d",i]];
        [defaults setObject:strName[i] forKey:[@"topName" stringByAppendingFormat:@"%d",i]];

    }
    [defaults synchronize];
}

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
 
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
#warning Potentially incomplete method implementation.
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
#warning Incomplete method implementation.
    // Return the number of rows in the section.
    return 10;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Top Score";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell==nil)
    {
        cell=[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    NSUserDefaults *defaults=[NSUserDefaults standardUserDefaults];
    
    NSString *name[20];
    for (int i=0; i<top; i++)
    {
        NSNumber *num=[defaults objectForKey:[@"top" stringByAppendingFormat:@"%d",i] ];
        topScore[i]=num.intValue;
        name[i]=[defaults objectForKey:[@"topName" stringByAppendingFormat:@"%d",i] ];
        if (name[i]==nil) name[i]=@"无名大侠";
        name[i]=[name[i] stringByAppendingString:@" : "];
    }

    
    cell.textLabel.text=[name[indexPath.row] stringByAppendingFormat:@"%d",topScore[indexPath.row]];
    return cell;
}

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }   
    else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
{
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Navigation logic may go here. Create and push another view controller.
    /*
     <#DetailViewController#> *detailViewController = [[<#DetailViewController#> alloc] initWithNibName:@"<#Nib name#>" bundle:nil];
     // ...
     // Pass the selected object to the new view controller.
     [self.navigationController pushViewController:detailViewController animated:YES];
     */
}

@end
