//
//  NormalCar.m
//  TrafficLigh
//
//  Created by 邱峰 on 12-11-1.
//  Copyright (c) 2012年 邱峰. All rights reserved.
//

#import "HomeWorkNormalCar.h"

@implementation HomeworkNormalCar


-(void) addCarAtPoint:(CGPoint) point
{
    if (direction==0)
    {
        carView=[[UITextField alloc] initWithFrame:CGRectMake(point.x, point.y, carWide, carLength)];
        [carView setBackground:[UIImage imageNamed:@"normalUp.png"]];
    }
    if (direction==1)
    {
         carView=[[UITextField alloc] initWithFrame:CGRectMake(point.x, point.y, carLength , carWide)];
        [carView setBackground:[UIImage imageNamed:@"normalRight.png"]];
    }
    if (direction==2)
    {
         carView=[[UITextField alloc] initWithFrame:CGRectMake(point.x, point.y, carWide, carLength)];
        [carView setBackground:[UIImage imageNamed:@"normalDown.png"]];
    }
    if (direction==3)
    {
        carView=[[UITextField alloc] initWithFrame:CGRectMake(point.x, point.y, carLength , carWide)];
        [carView setBackground:[UIImage imageNamed:@"normalLeft.png"]];
    }
    [carView setEnabled:false];
    [view addSubview:carView];
    state=0;
}

-(void) AtView:(UIView *) outsideView AtDirection:(int)whichDirection inQueue:(NSMutableArray *)queue
{
    state=-1;
    view=outsideView;
    queueCar=queue;
    speed=normalCarSpeed;
    direction=whichDirection;
    carDistance=20;
    [queue addObject:self];
}

-(BOOL) canMoveWithLight:(int)lightDirection
{
    CGPoint midPoint;
    CGPoint point[4];
    midPoint.x=view.bounds.size.width/2;
    midPoint.y=view.bounds.size.height/2;
    point[0].x=midPoint.x-103;
    point[0].y=midPoint.y-103;
    
    point[1].x=midPoint.x+103;
    point[1].y=midPoint.y-103;
    
    point[2].x=midPoint.x+103;
    point[2].y=midPoint.y+103;
    
    point[3].x=midPoint.x-103;
    point[3].y=midPoint.y+103;
    CGPoint carPoint;
    carPoint.x=carView.frame.origin.x;
    carPoint.y=carView.frame.origin.y;
    if (direction==0)
    {
        carPoint.y=carPoint.y+speed+carLength;
        if (lightDirection==1 && point[0].y-15<carPoint.y && carPoint.y<point[0].y) return false;
        return [self checkBeforeAndAfter:carView.frame.origin];
    }
    if (direction==1)
    {
        carPoint.x=carPoint.x-speed;
        if (lightDirection==0 && point[1].x<carPoint.x && carPoint.x<point[1].x+15) return false;
       //前后碰撞
        return  [self checkBeforeAndAfter:carView.frame.origin];
    }
    if (direction==2)
    {
        carPoint.y=carPoint.y-speed;
        if (lightDirection==1 && point[2].y<carPoint.y && carPoint.y<point[2].y+15) return false;
        return [self checkBeforeAndAfter:carView.frame.origin];
    }
    if (direction==3)
    {
        carPoint.x=carPoint.x+carLength+speed;
        if (lightDirection==0 && point[3].x-15<carPoint.x && carPoint.x<point[3].x) return false;
        return [self checkBeforeAndAfter:carView.frame.origin];
    }
    return false;
}

@end
