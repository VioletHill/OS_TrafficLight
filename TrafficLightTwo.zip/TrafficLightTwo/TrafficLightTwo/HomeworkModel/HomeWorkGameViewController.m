//
//  ViewController.m
//  TrafficLigh
//
//  Created by 邱峰 on 12-10-29.
//  Copyright (c) 2012年 邱峰. All rights reserved.
//

#import "HomeWorkViewController.h"
#import "HomeWorkLight.h"
#import "HomeWorkNormalCar.h"
#import "HomeWorkSpecialCar.h"



@interface HomeworkViewController ()

@property (strong, nonatomic) IBOutlet HomeworkLight *light;
@property (strong, nonatomic) IBOutlet UITextField *lightCount;

@end

@implementation HomeworkViewController
{
    NSMutableArray *queue[8];
    CGPoint carPosition[8];
    NSTimer *automicCarTimer;
}
@synthesize light = _light;
@synthesize lightCount;



- (void)viewDidLoad
{
    [super viewDidLoad];
    carPosition[0]=CGPointMake(295, 100);
    carPosition[1]=CGPointMake(700, 395);
    carPosition[2]=CGPointMake(440, 850);
    carPosition[3]=CGPointMake(20, 540);
    
    carPosition[4]=CGPointMake(345, 100);
    carPosition[5]=CGPointMake(700, 440);
    carPosition[6]=CGPointMake(395, 850);
    carPosition[7]=CGPointMake(20, 495);

    [lightCount setEnabled:FALSE];
    lightCount.text=@"7";
    
    for (int i=0; i<8; i++)
    {
        queue[i]=[NSMutableArray arrayWithCapacity:50];
    }
    [NSTimer scheduledTimerWithTimeInterval:8.0f target:self selector:@selector(turnLight) userInfo:NULL repeats:YES];
    [NSTimer scheduledTimerWithTimeInterval:0.1f target:self selector:@selector(callMove) userInfo:NULL repeats:YES];
    [NSTimer scheduledTimerWithTimeInterval:0.1f target:self selector:@selector(addCar) userInfo:NULL repeats:YES];
    [NSTimer scheduledTimerWithTimeInterval:1.0f target:self selector:@selector(turnNumber) userInfo:NULL repeats:YES];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload
{
    [self setLight:nil];
    [self setLightCount:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (IBAction)pressUpNormalCar:(UIButton *)sender
{
    HomeworkNormalCar *car=[[HomeworkNormalCar alloc] init];
    [car AtView:self.view AtDirection:0 inQueue:queue[0]];
}


- (IBAction)pressRightNormalCar:(UIButton *)sender
{
    HomeworkNormalCar *car=[[HomeworkNormalCar alloc] init];
    [car AtView:self.view AtDirection:1 inQueue:queue[1]];
}


- (IBAction)pressDownNormalCar:(UIButton *)sender
{
    HomeworkNormalCar *car=[[HomeworkNormalCar alloc] init];
    [car AtView:self.view AtDirection:2 inQueue:queue[2]];
}

- (IBAction)pressLeftNormalCar:(UIButton *)sender
{
    HomeworkNormalCar *car=[[HomeworkNormalCar alloc] init];
    [car AtView:self.view AtDirection:3 inQueue:queue[3]];
}

- (IBAction)pressUpSpecialCar:(UIButton *)sender
{
    HomeworkSpecialCar *car=[[HomeworkSpecialCar alloc] init];
    [car AtView:self.view AtDirection:0 inQueue:queue[4]];
}

- (IBAction)pressRightSpecialCar:(UIButton *)sender
{
    HomeworkSpecialCar *car=[[HomeworkSpecialCar alloc] init];
    [car AtView:self.view AtDirection:1 inQueue:queue[5]];
}

- (IBAction)pressDownSpecialCar:(UIButton *)sender
{
    HomeworkSpecialCar *car=[[HomeworkSpecialCar alloc] init];
    [car AtView:self.view AtDirection:2 inQueue:queue[6]];
}

- (IBAction)pressLeftSpecialCar:(UIButton *)sender
{
    HomeworkSpecialCar *car=[[HomeworkSpecialCar alloc] init];
    [car AtView:self.view AtDirection:3 inQueue:queue[7]];
}


-(void) turnNumber
{
    int number=lightCount.text.intValue;
    if (number==0)  number=7;
    else number--;
    lightCount.text=[NSString stringWithFormat:@"%d",number];
}

-(void) turnLight
{
    self.light.direction=self.light.direction ^ 1;
}

-(void) callMove
{
    
    for (int i=0; i<8; i++)
    {
        for (int j=0; j<[queue[i] count]; j++)
        {
            HomeworkCar *car=(HomeworkCar *)[queue[i] objectAtIndex:j];
            if ((car->carView.frame.origin.x)<-50 || car->carView.frame.origin.x>self.view.frame.size.width+50 || car->carView.frame.origin.y<-50 || car->carView.frame.origin.y>self.view.frame.size.height+50)
            {
                [queue[i] removeObjectAtIndex:j];
                j--;
                continue;
            }
            else break;
        }
        for (int j=0; j<[queue[i] count]; j++)
        {
            HomeworkCar *car=(HomeworkCar *)[queue[i] objectAtIndex:j];
            if (car->state==-1) continue;
            if ((i<4 && [(HomeworkNormalCar *)car canMoveWithLight:self.light.direction]) || (i>=4 && [((HomeworkSpecialCar *)car) checkBeforeAndAfter:car->carView.frame.origin]))
            {
                for (int k=(i&1) ^ 1; k<8; k=k+2)
                    if (![car checkLeftRihtwithQueue:queue[k]]) goto FailMove;
                [car move];
            }
            FailMove: continue;
        }
    }
}

-(void) addCar
{
    for (int j=0; j<4; j++)
    {
        for (int i=0; i<[queue[j] count]; i++)
        {
            HomeworkNormalCar *car=(HomeworkNormalCar *)[queue[j] objectAtIndex:i];
            if (car->state==-1)
            {
                if ([car checkBeforeAndAfter:carPosition[j]])
                {
                    [car addCarAtPoint:carPosition[j]];
                }
                break;
            }
        }
    }
    for (int j=4; j<8; j++)
    {
        for (int i=0; i<[queue[j] count]; i++)
        {
            HomeworkSpecialCar *car=(HomeworkSpecialCar *)[queue[j] objectAtIndex:i];
            if (car->state==-1)
            {
                if ([car checkBeforeAndAfter:carPosition[j]])
                {
                    [car addCarAtPoint:carPosition[j]];
                }
                break;
            }
        }
    }

}

-(BOOL) shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation
{
    return NO;
}

- (IBAction)pressAutomicCar:(UIButton *)sender
{
    if ([automicCarTimer isValid]) return ;
    automicCarTimer=[NSTimer scheduledTimerWithTimeInterval:1.5f target:self selector:@selector(automicCar) userInfo:NULL repeats:YES];
}

- (IBAction)pressCloseAutomicCar:(UIButton *)sender
{
    [automicCarTimer invalidate];
}


-(void) automicCar
{
    int randomNumber=arc4random()%4;
    int randomSpecial=arc4random()%5;
    if (randomSpecial!=4 && ([queue[randomNumber] count]!=0))
    {
        HomeworkNormalCar *car;
        car=(HomeworkNormalCar *)[queue[randomNumber] lastObject];
        if (car->state==-1) return ;
    }
    switch (randomNumber) {
        case 0:
            if (randomSpecial==4) [self pressUpSpecialCar:NULL];
            else    [self pressUpNormalCar:NULL];
            break;
        case 1:
            if (randomSpecial==4) [self pressRightSpecialCar:NULL];
            else [self pressRightNormalCar:NULL];
            break;
        case 2:
            if (randomSpecial==4) [self pressDownSpecialCar:NULL];
            else [self pressDownNormalCar:NULL];
            break;
        case 3:
            if (randomSpecial==4) [self pressLeftSpecialCar:NULL];
            else [self pressLeftNormalCar:NULL];
            break;
        default:
            break;
    }
}

@end
