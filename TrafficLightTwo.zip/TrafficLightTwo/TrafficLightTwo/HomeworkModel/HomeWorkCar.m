//
//  Car.m
//  TrafficLigh
//
//  Created by 邱峰 on 12-10-31.
//  Copyright (c) 2012年 邱峰. All rights reserved.
//

#import "HomeWorkCar.h"


@implementation HomeworkCar

-(BOOL) checkBeforeAndAfter:(CGPoint)point
{
    HomeworkCar *car;
    if (self==[queueCar objectAtIndex:0]) return true;

    for (int i=0; i<[queueCar count]-1; i++)
    {
        car =(HomeworkCar *) [queueCar objectAtIndex:i];
        if ( [queueCar objectAtIndex:(i+1)]==self ) break;
    }
    UITextField *lastCar=car->carView;
    switch (direction)
    {
        case 0:
            if (lastCar.frame.origin.y-point.y<carDistance+carLength) return false;
            else return true;
        case 1:
            if (point.x-lastCar.frame.origin.x<carDistance+carLength) return false;
            else return true;
        case 2:
            if (point.y-lastCar.frame.origin.y<carDistance+carLength) return false;
            else return true;
        case 3:
            if (lastCar.frame.origin.x-point.x<carDistance+carLength) return false;
            else return true;
        default:
            return true;
    }
}

-(BOOL) checkLeftRihtwithQueue:(NSMutableArray *)queue
{
    CGPoint headPoint;
    CGPoint carPoint;
    for (int i=0; i<[queue count]; i++)
    {
        HomeworkCar *car=(HomeworkCar *) [queue objectAtIndex:i];
        
        carPoint.x=car->carView.frame.origin.x;
        carPoint.y=car->carView.frame.origin.y;
        if (direction==0)
        {
            headPoint.y=carView.frame.origin.y+carLength;
            headPoint.x=carView.frame.origin.x;
            if (car->direction==1 || car->direction==3)
            {
                if ( (carPoint.x<headPoint.x && headPoint.x<carPoint.x+carLength) || (carPoint.x<headPoint.x+carWide && headPoint.x+carWide<carPoint.x+carLength) )
                {
                   if (headPoint.y<=carPoint.y-10 && headPoint.y+speed>=carPoint.y-10)
                       return false;
                }
                if (car->direction==1)
                {
                    if ( (carPoint.x-speed-20<=headPoint.x && headPoint.x<=carPoint.x-20-speed+carLength) || (carPoint.x-speed-20<=headPoint.x+carWide && headPoint.x+carWide<=carPoint.x-speed+carLength-20) )
                    {
                        if (headPoint.y<=carPoint.y-10 && headPoint.y+speed>=carPoint.y-10)
                            return false;
                    }
                }
            }
        }
        if (direction==1)
        {
            headPoint.x=carView.frame.origin.x;
            headPoint.y=carView.frame.origin.y;
            if (car->direction==0 || car->direction==2)
            {
                if ( (carPoint.y<headPoint.y && headPoint.y<carPoint.y+carLength) || (carPoint.y<headPoint.y+carWide && headPoint.y+carWide<carPoint.y+carLength) )
                {
                    if (carPoint.x+carWide+10<=headPoint.x && headPoint.x-speed<=carPoint.x+carWide+10)
                        return false;
                }
                if (car->direction==2)
                {
                    if ( (carPoint.y-speed-20<=headPoint.y && headPoint.y<=carPoint.y-20-speed+carLength) || (carPoint.y-speed-20<=headPoint.y+carWide && headPoint.y+carWide<=carPoint.y-speed+carLength-20) )
                    {
                        if (carPoint.x+carWide+10<=headPoint.x && headPoint.x-speed<=carPoint.x+carWide+10)
                            return false;
                    }
                }
            }
        }
        if (direction==2)
        {
            headPoint.x=carView.frame.origin.x;
            headPoint.y=carView.frame.origin.y;
            if (car->direction==1 || car->direction==3)
            {
                if ( (carPoint.x<headPoint.x && headPoint.x<carPoint.x+carLength) || (carPoint.x<headPoint.x+carWide && headPoint.x+carWide<carPoint.x+carLength) )
                {
                    if (headPoint.y>=carPoint.y+10+carWide && headPoint.y-speed<=carPoint.y+10+carWide)
                        return false;

                }
                if (car->direction==3)
                {
                    if ( (carPoint.x+speed+20<=headPoint.x && headPoint.x<=carPoint.x+20+speed+carLength) || (carPoint.x+speed+20<=headPoint.x+carWide && headPoint.x+carWide<=carPoint.x+speed+carLength+20) )
                    {
                        if (headPoint.y>=carPoint.y+10+carWide && headPoint.y-speed<=carPoint.y+10+carWide)
                            return false;
                    }
                }
            }
        }
        if (direction==3)
        {
            headPoint.x=carView.frame.origin.x+carLength;
            headPoint.y=carView.frame.origin.y;
            if ( (carPoint.y<headPoint.y && headPoint.y<carPoint.y+carLength) || (carPoint.y<headPoint.y+carWide && headPoint.y+carWide<carPoint.y+carLength) )
            {
                if (headPoint.x<=carPoint.x-10 && headPoint.x+speed>=carPoint.x-10)
                    return false;
            }
            if (car->direction==0)
            {
               if ( (carPoint.y+speed+20<=headPoint.y && headPoint.y<=carPoint.y+20+speed+carLength) || (carPoint.y+speed+20<=headPoint.y+carWide && headPoint.y+carWide<=carPoint.y+speed+carLength+20) )
                {
                    if (headPoint.x<=carPoint.x-10 && headPoint.x+speed>=carPoint.x-10)
                        return false;
                }
            }
        }
        
        
    }
    return true;
}

-(void) move
{
    [UIImageView beginAnimations:nil context:NULL];
    [UIImageView setAnimationDuration:0.1];
    if (direction==0)
    {
        carView.frame=CGRectMake(carView.frame.origin.x, carView.frame.origin.y+speed, carWide, carLength);
    }
    else if (direction==1)
    {
        carView.frame=CGRectMake(carView.frame.origin.x-speed, carView.frame.origin.y, carLength, carWide);
    }
    else if (direction==2)
    {
        carView.frame=CGRectMake(carView.frame.origin.x, carView.frame.origin.y-speed, carWide, carLength);
    }
    else if (direction==3)
    {
        carView.frame=CGRectMake(carView.frame.origin.x+speed, carView.frame.origin.y, carLength, carWide);
    }
    [UIView commitAnimations];
}

@end
