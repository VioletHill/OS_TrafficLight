//
//  SpecialCar.m
//  TrafficLigh
//
//  Created by 邱峰 on 12-11-1.
//  Copyright (c) 2012年 邱峰. All rights reserved.
//

#import "HomeWorkSpecialCar.h"
#import "AVFoundation/AVFoundation.h"


@implementation HomeworkSpecialCar


-(void) addCarAtPoint:(CGPoint) point
{
    if (direction==0)
    {
        carView=[[UITextField alloc] initWithFrame:CGRectMake(point.x, point.y, carWide, carLength)];
        [carView setBackground:[UIImage imageNamed:@"specialUp.png"]];
    }
    if (direction==1)
    {
        carView=[[UITextField alloc] initWithFrame:CGRectMake(point.x, point.y, carLength , carWide)];
        [carView setBackground:[UIImage imageNamed:@"specialRight.png"]];
    }
    if (direction==2)
    {
        carView=[[UITextField alloc] initWithFrame:CGRectMake(point.x, point.y, carWide, carLength)];
        [carView setBackground:[UIImage imageNamed:@"specialDown.png"]];
    }
    if (direction==3)
    {
        carView=[[UITextField alloc] initWithFrame:CGRectMake(point.x, point.y, carLength , carWide)];
        [carView setBackground:[UIImage imageNamed:@"specialLeft.png"]];
    }
    [carView setEnabled:false];
    [view addSubview:carView];
    state=0;
}

-(void) AtView:(UIView *) outsideView AtDirection:(int)whichDirection inQueue:(NSMutableArray *)queue
{
    state=-1;
    view=outsideView;
    queueCar=queue;
    speed=specialCarSpeed;
    direction=whichDirection;
    carDistance=200;
    [queue addObject:self];
}


@end
