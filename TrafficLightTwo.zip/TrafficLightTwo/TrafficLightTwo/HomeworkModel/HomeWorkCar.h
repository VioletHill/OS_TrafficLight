//
//  Car.h
//  TrafficLigh
//
//  Created by 邱峰 on 12-10-31.
//  Copyright (c) 2012年 邱峰. All rights reserved.
//

#import <Foundation/Foundation.h>

static const int carWide=30;
static const int carLength=40;
static const int specialCarSpeed=10;
static const int normalCarSpeed=5;

@interface HomeworkCar : NSObject
{
@public
    int speed;
    int state;
    int carDistance;
    NSMutableArray *queueCar;
    UIView * view;
    int direction;
    UITextField *carView;
}

-(BOOL) checkBeforeAndAfter:(CGPoint)point;
-(BOOL) checkLeftRihtwithQueue:(NSMutableArray *)queue;
-(void) move;

@end

