//
//  Light.h
//  TrafficLigh
//
//  Created by 邱峰 on 12-10-29.
//  Copyright (c) 2012年 邱峰. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomeworkLight : UIView

@property (nonatomic) int direction;

@end