//
//  SpecialCar.h
//  TrafficLigh
//
//  Created by 邱峰 on 12-11-1.
//  Copyright (c) 2012年 邱峰. All rights reserved.
//

#import "HomeWorkCar.h"

@interface HomeworkSpecialCar : HomeworkCar

-(void) addCarAtPoint:(CGPoint) point;
-(void) AtView:(UIView *) outsideView AtDirection:(int)whichDirection inQueue:(NSMutableArray *)queue;

@end
