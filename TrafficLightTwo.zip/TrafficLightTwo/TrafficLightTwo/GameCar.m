//
//  Car.m
//  TrafficLightTwo
//
//  Created by 邱峰 on 12-11-9.
//  Copyright (c) 2012年 VioletHill. All rights reserved.
//

#import "GameCar.h"

@implementation GameCar

+(void) setGameViewController:(GameViewController *)viewController
{
    gameViewController=viewController;
}

-(BOOL) checkBeforeAndAfter:(CGPoint)point
{
    GameCar *car;
    if (self==[queueCar objectAtIndex:0]) return true;
    
    for (int i=0; i<[queueCar count]-1; i++)
    {
        car =(GameCar *) [queueCar objectAtIndex:i];
        if ( [queueCar objectAtIndex:(i+1)]==self ) break;
    }
    UIButton *lastCar=car->carView;
    switch (direction)
    {
        case 0:
            if (lastCar.frame.origin.y-point.y<carDistance+carLength) return false;
            else return true;
        case 1:
            if (point.x-lastCar.frame.origin.x<carDistance+carLength) return false;
            else return true;
        case 2:
            if (point.y-lastCar.frame.origin.y<carDistance+carLength) return false;
            else return true;
        case 3:
            if (lastCar.frame.origin.x-point.x<carDistance+carLength) return false;
            else return true;
        default:
            return true;
    }
}

-(BOOL) checkLeftRihtwithQueue:(NSMutableArray *)queue
{
    CGPoint headPoint;
    CGPoint carPoint;
    for (int i=0; i<[queue count]; i++)
    {
        GameCar *car=(GameCar *) [queue objectAtIndex:i];
        
        carPoint.x=car->carView.frame.origin.x;
        carPoint.y=car->carView.frame.origin.y;
        if (direction==0)
        {
            headPoint.y=carView.frame.origin.y+carLength;
            headPoint.x=carView.frame.origin.x;
            if (car->direction==1 || car->direction==3)
            {
                if ( (carPoint.x<headPoint.x && headPoint.x<carPoint.x+carLength) || (carPoint.x<headPoint.x+carWide && headPoint.x+carWide<carPoint.x+carLength) )
                {
                    if (headPoint.y<=carPoint.y-10 && headPoint.y+speed>=carPoint.y-10)
                        return false;
                }
                if (car->direction==1)
                {
                    if ( (carPoint.x-speed-20<=headPoint.x && headPoint.x<=carPoint.x-20-speed+carLength) || (carPoint.x-speed-20<=headPoint.x+carWide && headPoint.x+carWide<=carPoint.x-speed+carLength-20) )
                    {
                        if (headPoint.y<=carPoint.y-10 && headPoint.y+speed>=carPoint.y-10)
                            return false;
                    }
                }
            }
        }
        if (direction==1)
        {
            headPoint.x=carView.frame.origin.x;
            headPoint.y=carView.frame.origin.y;
            if (car->direction==0 || car->direction==2)
            {
                if ( (carPoint.y<headPoint.y && headPoint.y<carPoint.y+carLength) || (carPoint.y<headPoint.y+carWide && headPoint.y+carWide<carPoint.y+carLength) )
                {
                    if (carPoint.x+carWide+10<=headPoint.x && headPoint.x-speed<=carPoint.x+carWide+10)
                        return false;
                }
                if (car->direction==2)
                {
                    if ( (carPoint.y-speed-20<=headPoint.y && headPoint.y<=carPoint.y-20-speed+carLength) || (carPoint.y-speed-20<=headPoint.y+carWide && headPoint.y+carWide<=carPoint.y-speed+carLength-20) )
                    {
                        if (carPoint.x+carWide+10<=headPoint.x && headPoint.x-speed<=carPoint.x+carWide+10)
                            return false;
                    }
                }
            }
        }
        if (direction==2)
        {
            headPoint.x=carView.frame.origin.x;
            headPoint.y=carView.frame.origin.y;
            if (car->direction==1 || car->direction==3)
            {
                if ( (carPoint.x<headPoint.x && headPoint.x<carPoint.x+carLength) || (carPoint.x<headPoint.x+carWide && headPoint.x+carWide<carPoint.x+carLength) )
                {
                    if (headPoint.y>=carPoint.y+10+carWide && headPoint.y-speed<=carPoint.y+10+carWide)
                        return false;
                    
                }
                if (car->direction==3)
                {
                    if ( (carPoint.x+speed+20<=headPoint.x && headPoint.x<=carPoint.x+20+speed+carLength) || (carPoint.x+speed+20<=headPoint.x+carWide && headPoint.x+carWide<=carPoint.x+speed+carLength+20) )
                    {
                        if (headPoint.y>=carPoint.y+10+carWide && headPoint.y-speed<=carPoint.y+10+carWide)
                            return false;
                    }
                }
            }
        }
        if (direction==3)
        {
            headPoint.x=carView.frame.origin.x+carLength;
            headPoint.y=carView.frame.origin.y;
            if ( (carPoint.y<headPoint.y && headPoint.y<carPoint.y+carLength) || (carPoint.y<headPoint.y+carWide && headPoint.y+carWide<carPoint.y+carLength) )
            {
                if (headPoint.x<=carPoint.x-10 && headPoint.x+speed>=carPoint.x-10)
                    return false;
            }
            if (car->direction==0)
            {
                if ( (carPoint.y+speed+20<=headPoint.y && headPoint.y<=carPoint.y+20+speed+carLength) || (carPoint.y+speed+20<=headPoint.y+carWide && headPoint.y+carWide<=carPoint.y+speed+carLength+20) )
                {
                    if (headPoint.x<=carPoint.x-10 && headPoint.x+speed>=carPoint.x-10)
                        return false;
                }
            }
        }
        
        
    }
    return true;
}

-(void) move
{
    [UIImageView beginAnimations:nil context:NULL];
    [UIImageView setAnimationDuration:0.1];
    if (direction==0)
    {
        carView.frame=CGRectMake(carView.frame.origin.x, carView.frame.origin.y+speed, carWide, carLength);
    }
    else if (direction==1)
    {
        carView.frame=CGRectMake(carView.frame.origin.x-speed, carView.frame.origin.y, carLength, carWide);
    }
    else if (direction==2)
    {
        carView.frame=CGRectMake(carView.frame.origin.x, carView.frame.origin.y-speed, carWide, carLength);
    }
    else if (direction==3)
    {
        carView.frame=CGRectMake(carView.frame.origin.x+speed, carView.frame.origin.y, carLength, carWide);
    }
    [UIView commitAnimations];
}


-(void) addCarAtPoint:(CGPoint) point
{
    if (direction==0)
    {
        carView=[[UIButton alloc] initWithFrame:CGRectMake(point.x, point.y, carWide, carLength)];
        if (!whoAmI)  [carView setBackgroundImage:[UIImage imageNamed:@"normalUp.png"] forState:UIControlStateNormal];
        else [carView setBackgroundImage:[UIImage imageNamed:@"specialUp.png"] forState:UIControlStateNormal];
    }
    if (direction==1)
    {
        carView=[[UIButton alloc] initWithFrame:CGRectMake(point.x, point.y, carLength , carWide)];
        if (!whoAmI) [carView setBackgroundImage:[UIImage imageNamed:@"normalRight.png"] forState:UIControlStateNormal];
        else [carView setBackgroundImage:[UIImage imageNamed:@"specialRight.png"] forState:UIControlStateNormal];
    }
    if (direction==2)
    {
        carView=[[UIButton alloc] initWithFrame:CGRectMake(point.x, point.y, carWide, carLength)];
        if (!whoAmI) [carView setBackgroundImage:[UIImage imageNamed:@"normalDown.png"] forState:UIControlStateNormal];
        else [carView setBackgroundImage:[UIImage imageNamed:@"specialDown.png"] forState:UIControlStateNormal];
    }
    if (direction==3)
    {
        carView=[[UIButton alloc] initWithFrame:CGRectMake(point.x, point.y, carLength , carWide)];
        if (!whoAmI) [carView setBackgroundImage:[UIImage imageNamed:@"normalLeft.png"] forState:UIControlStateNormal];
        else [carView setBackgroundImage:[UIImage imageNamed:@"specialLeft.png"] forState:UIControlStateNormal];
    }
    [carView addTarget:self action:@selector(changeStop:) forControlEvents:UIControlEventTouchUpInside];
    [view addSubview:carView];
    state=0;
}

-(void) changeStop:(UIButton *)sender
{
    //return;
    if (whoAmI) [gameViewController gameover];

    CGPoint midPoint;
    CGPoint point[4];
    midPoint.x=view.bounds.size.width/2;
    midPoint.y=view.bounds.size.height/2;
    point[0].x=midPoint.x-103;
    point[0].y=midPoint.y-103;
    
    point[1].x=midPoint.x+103;
    point[1].y=midPoint.y-103;
    
    point[2].x=midPoint.x+103;
    point[2].y=midPoint.y+103;
    
    point[3].x=midPoint.x-103;
    point[3].y=midPoint.y+103;
    if (direction==0)
    {
        int head=carView.frame.origin.y+carLength;
        if (point[0].y-gameViewController.light.shortDistance-10<head && head<point[0].y-10)
        {
            stop=true;
            return ;
        }
        if (head<point[0].y-gameViewController.light.farDistance-10) [gameViewController gameover];
    }
    if (direction==1)
    {
        int head=carView.frame.origin.x;
        if (point[1].x+gameViewController.light.shortDistance+10>head && head>point[1].x+10)
        {
            stop=true;
            return ;
        }
        if (head>point[1].x+gameViewController.light.shortDistance+10) [gameViewController gameover];
    }
    if (direction==2)
    {
        int head=carView.frame.origin.y;
        if (point[2].y+10<head && head<point[2].y+gameViewController.light.shortDistance+10)
        {
            stop=true;
            return ;
        }
        if (head>point[2].y+gameViewController.light.farDistance+10) [gameViewController gameover];
    }
    if (direction==3)
    {
        int head=carView.frame.origin.x+carLength;
        if (point[3].x-gameViewController.light.shortDistance-10<head && head<point[3].x-10)
        {
            stop=true;
            return ;
        }
        if (head<point[3].x-gameViewController.light.farDistance-10) [gameViewController gameover];
    }
    if ( (direction==1 || direction==3) && gameViewController.light.direction==1)  [gameViewController gameover];
    if ( (direction==0 ||  direction==2) && gameViewController.light.direction==0)  [gameViewController gameover];
    stop=true;
}

+(void) changeSpeed
{
    if (normalCarSpeed<10) normalCarSpeed++;
    if (specialCarSpeed<15) specialCarSpeed++;
}

+(void) setNormalCarSpeed:(int) speed
{
    normalCarSpeed=speed;
}

+(void) setSpecialCarSpeed:(int) speed
{
    specialCarSpeed=speed;
}

-(void) AtView:(UIView *) outsideView AtDirection:(int)whichDirection inQueue:(NSMutableArray *)queue withWho:(BOOL)isSpecial
{
    if (isSpecial)
        speed=specialCarSpeed;
    else
        speed=normalCarSpeed;
    
    stop=false;
    whoAmI=isSpecial;
    state=-1;
    view=outsideView;
    queueCar=queue;
    direction=whichDirection;
    carDistance=20;
    [queue addObject:self];
}

-(BOOL) runRedLight:(int)lightDirection
{
    if (whoAmI) return false;
    if (stop) return false;
    CGPoint midPoint;
    CGPoint point[4];
    midPoint.x=view.bounds.size.width/2;
    midPoint.y=view.bounds.size.height/2;
    point[0].x=midPoint.x-103;
    point[0].y=midPoint.y-103;
    
    point[1].x=midPoint.x+103;
    point[1].y=midPoint.y-103;
    
    point[2].x=midPoint.x+103;
    point[2].y=midPoint.y+103;
    
    point[3].x=midPoint.x-103;
    point[3].y=midPoint.y+103;
    CGPoint carPoint;
    carPoint.x=carView.frame.origin.x;
    carPoint.y=carView.frame.origin.y;
    if (direction==0)
    {
        carPoint.y=carPoint.y+carLength;
        if (lightDirection==1 && carPoint.y<point[0].y-10 && carPoint.y+speed>point[0].y-10) return true;
        else return false;
    }
    if (direction==1)
    {
        carPoint.x=carPoint.x;
        if (lightDirection==0 && point[1].x+10<carPoint.x && carPoint.x-speed<point[1].x+10) return true;
        else return  false;
    }
    if (direction==2)
    {
        carPoint.y=carPoint.y;
        if (lightDirection==1 && point[2].y+10<carPoint.y && carPoint.y-speed<point[2].y+10) return true;
        else return false;
    }
    if (direction==3)
    {
        carPoint.x=carPoint.x+carLength;
        if (lightDirection==0 && carPoint.x<point[3].x-10 && carPoint.x+speed>point[3].x-10) return true;
        else return false;
    }
    return false;
}

@end
