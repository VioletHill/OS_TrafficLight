//
//  TopScoreViewController.h
//  TrafficLightTwo
//
//  Created by 邱峰 on 12-11-12.
//  Copyright (c) 2012年 VioletHill. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TopScoreViewController : UITableViewController

+(void) setScore:(int)score withName:(NSString *)str;
+(BOOL) isTop:(int) score;
@end
