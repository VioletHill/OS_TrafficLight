//
//  GameLight.h
//  TrafficLightTwo
//
//  Created by 邱峰 on 12-11-8.
//  Copyright (c) 2012年 VioletHill. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GameLight : UIView

@property (nonatomic) int direction;
@property (nonatomic) int farDistance;
@property (nonatomic) int shortDistance;
@property (nonatomic) UIColor *color;
@end
