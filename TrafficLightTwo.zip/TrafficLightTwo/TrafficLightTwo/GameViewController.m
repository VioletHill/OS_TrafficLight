//
//  GameViewController.m
//  TrafficLightTwo
//
//  Created by 邱峰 on 12-11-8.
//  Copyright (c) 2012年 VioletHill. All rights reserved.
//

#import "GameViewController.h"
#import "GameLight.h"
#import "GameCar.h"
#import "TopScoreViewController.h"
#import "GameOverController.h"


@interface GameViewController ()

@property (strong, nonatomic) IBOutlet UITextField *score;
@property (nonatomic) int scoreNum;
@property (strong, nonatomic) IBOutlet UIButton *gameoverButton;

@end

@implementation GameViewController
{
    NSMutableArray *queue[8];
    CGPoint carPosition[8];
    int lightTime;
    int randomLightTime;
    int automicCarSpeedTime;
    bool isGameover;
    int road;
    NSTimer *callMoveTimer;
    NSTimer *addCarTimer;
    NSTimer *lightTimer;
    NSTimer *automicTimer;
}
@synthesize score;
@synthesize scoreNum=_scoreNum;
@synthesize gameoverButton;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}



- (void)viewDidLoad
{
    isGameover=false;
    [super viewDidLoad];
    [GameCar setGameViewController:self];
    gameoverButton.hidden=true;
    road=4;
    [GameCar setNormalCarSpeed:5];
    [GameCar setSpecialCarSpeed:10];
    self.light.farDistance=200;
    self.light.shortDistance=100;
    self.light.color=[UIColor purpleColor];
    lightTime=7.0;
    randomLightTime=2.0;
    automicCarSpeedTime=3.0;
	for (int i=0; i<8; i++)
    {
        if (queue[i]==nil) queue[i]=[NSMutableArray arrayWithCapacity:50];
        [queue[i] removeAllObjects];
    }
    
    carPosition[0]=CGPointMake(295, 100);
    carPosition[1]=CGPointMake(700, 395);
    carPosition[2]=CGPointMake(440, 850);
    carPosition[3]=CGPointMake(20, 540);
    
    carPosition[4]=CGPointMake(345, 100);
    carPosition[5]=CGPointMake(700, 440);
    carPosition[6]=CGPointMake(395, 850);
    carPosition[7]=CGPointMake(20, 495);
    
    callMoveTimer=[NSTimer scheduledTimerWithTimeInterval:0.1f target:self selector:@selector(callMove) userInfo:NULL repeats:YES];
    addCarTimer=[NSTimer scheduledTimerWithTimeInterval:0.1f target:self selector:@selector(addCar) userInfo:NULL repeats:YES];
    [self setLightTime];
    [self setAutomicTime];

}

- (void)viewDidUnload
{

    [self setGameoverButton:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

-(void) setAutomicTime
{
    [self automicCar];
    automicTimer=[NSTimer scheduledTimerWithTimeInterval:automicCarSpeedTime target:self selector:@selector(setAutomicTime) userInfo:NULL repeats:FALSE];
}

-(void) setLightTime
{
    float time=lightTime+arc4random()%100/100*randomLightTime;
    lightTimer=[NSTimer scheduledTimerWithTimeInterval:time target:self selector:@selector(setLightTime) userInfo:NULL repeats:false];
    [NSTimer scheduledTimerWithTimeInterval:time-0.8 target:self selector:@selector(setWhiteWarning) userInfo:NULL repeats:false];
    [NSTimer scheduledTimerWithTimeInterval:time-0.6 target:self selector:@selector(setpurpleWarning) userInfo:NULL repeats:false];
    [NSTimer scheduledTimerWithTimeInterval:time-0.4 target:self selector:@selector(setWhiteWarning) userInfo:NULL repeats:false];
    [NSTimer scheduledTimerWithTimeInterval:time-0.2 target:self selector:@selector(setpurpleWarning) userInfo:NULL repeats:false];
    [self turnLight];
}

-(void) setWhiteWarning
{
    self.light.color=[UIColor whiteColor];
}

-(void) setpurpleWarning
{
    self.light.color=[UIColor purpleColor];
}

-(void) setScoreNum:(int)scoreNum
{
    if (_scoreNum==scoreNum) return ;
    _scoreNum=scoreNum;
    if (_scoreNum%10==0 && _scoreNum!=0)
    {
        if (lightTime>2) lightTime=lightTime-0.05;
        if (randomLightTime>1) randomLightTime=randomLightTime-0.1;
        if (self.light.farDistance>80) self.light.farDistance-=10;
        [GameCar changeSpeed];
        if (automicCarSpeedTime>1.5) automicCarSpeedTime=automicCarSpeedTime-0.05;
        if (self.light.shortDistance>20) self.light.shortDistance-=5;
    }
}

-(void) addCar
{
    for (int i=0; i<8; i++)
    {
        for (int j=0; j<[queue[i] count]; j++)
        {
            GameCar *car=(GameCar *)[queue[i] objectAtIndex:j];
            if (car->state==-1)
            {
                if ([car checkBeforeAndAfter:carPosition[i]])
                {
                    [car addCarAtPoint:carPosition[i]];
                }
                break;
            }
        }
    }
}

-(void) gameover;
{
    if (isGameover) return ;
    isGameover=true;
    gameoverButton.hidden=false;
    [gameoverButton setTitle:[@"游戏结束，你的得分为:" stringByAppendingString:self.score.text] forState:UIControlStateNormal];
    [lightTimer invalidate];
    [addCarTimer invalidate];
    [callMoveTimer invalidate];
    [automicTimer invalidate];
    
    for (int i=0; i<8; i++)
    {
        for (int j=0; j<[queue[i] count]; j++)
        {
            GameCar *car=(GameCar *)[queue[i] objectAtIndex:j];
            [car->carView removeFromSuperview];
        }
    }
    if ([TopScoreViewController isTop:_scoreNum])
    {
        GameOverController *gameoverController;
        gameoverController=[self.storyboard instantiateViewControllerWithIdentifier:@"GameOver"];
        gameoverController.score=_scoreNum;
        [self.navigationController pushViewController:gameoverController animated:true];
    }

}
- (IBAction)chooseFour:(UIButton *)sender
{
    road=4;
}

- (IBAction)chooseEight:(UIButton *)sender
{
    road=8;
}

-(void) callMove
{
    for (int i=0; i<8; i++)
    {
        for (int j=0; j<[queue[i] count]; j++)
        {
            GameCar *car=(GameCar *)[queue[i] objectAtIndex:j];
            if (car->carView.frame.origin.x< -carLength || car->carView.frame.origin.x>self.view.frame.size.width+carLength || car->carView.frame.origin.y<-carLength || car->carView.frame.origin.y>self.view.frame.size.height+carLength)
            {
                self.scoreNum=score.text.intValue+1;
                score.text=[NSString stringWithFormat:@"%d",self.scoreNum];
                [queue[i] removeObjectAtIndex:j];
                j--;
                continue;
            }
            else break;
        }
        for (int j=0; j<[queue[i] count]; j++)
        {
            GameCar *car=(GameCar *)[queue[i] objectAtIndex:j];
            if (isGameover) return;
            if (car->state==-1) continue;
            if (car->stop) continue;

            if ([car runRedLight:self.light.direction])
            {
                [self gameover];
                return ;
            }
            
            if ([car checkBeforeAndAfter:car->carView.frame.origin])
            {
                for (int k=(i&1) ^ 1; k<8; k=k+2)
                {
                    if (![car checkLeftRihtwithQueue:queue[k]])
                        goto FailMove2;
                }
                [car move];
            }
        FailMove2: continue;
        }
    }
}

-(void) automicCar
{
    int randomNumber=arc4random()%road;
    BOOL randomSpecial=arc4random()%5;
    GameCar *car=[[GameCar alloc] init];
    [car AtView:self.view AtDirection:randomNumber%4 inQueue:queue[randomNumber] withWho:randomSpecial==0];
}


-(void) turnLight
{
    self.light.direction=self.light.direction ^ 1;
    for (int i=0; i<8; i++)
        for (int j=0; j<[queue[i] count]; j++)
        {
            GameCar *car=[queue[i] objectAtIndex:j];
            if ((car->direction%2)==self.light.direction && car->stop) car->stop=false;
        }

}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return false;
}

@end
